DockPanel Suite
===============

[![Join the chat at https://gitter.im/dockpanelsuite/dockpanelsuite](https://img.shields.io/gitter/room/dockpanelsuite/dockpanelsuite.svg?style=flat-square)](https://gitter.im/dockpanelsuite/dockpanelsuite?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![NuGet Version](https://img.shields.io/nuget/v/DockPanelSuite.svg?style=flat-square)](https://www.nuget.org/packages/DockPanelSuite/)
[![Build status](https://img.shields.io/github/actions/workflow/status/dockpanelsuite/dockpanelsuite/main.yml?style=flat-square)](https://github.com/dockpanelsuite/dockpanelsuite/actions?query=workflow%3ACI)

> **This project is looking for new maintainers. Please read [this](https://github.com/dockpanelsuite/dockpanelsuite/issues/663) for more information.**

DockPanel Suite - The Visual Studio inspired docking library for .NET WinForms

For more details, check out [http://dockpanelsuite.com](http://dockpanelsuite.com).

Visual Studio 2019 Community edition and above is recommended to compile the code base.

> **If you look for alternative options, use a search engine to learn more about better components like Krypton Docking.**
