using System.Windows.Forms;

namespace DockSample
{
    public partial class DummyTaskList : ToolWindow
    {
        public DummyTaskList()
        {
            InitializeComponent();
        }
    }
}