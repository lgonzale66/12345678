using System.Windows.Forms;

namespace DockSample
{
    public partial class DummyOutputWindow : ToolWindow
    {
        public DummyOutputWindow()
        {
            InitializeComponent();
        }
    }
}